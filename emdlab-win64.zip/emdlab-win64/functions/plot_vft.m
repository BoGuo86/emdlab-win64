
function plot_vft(a,p,f)




end
