classdef emdlab_mlib_pm_Y22H < handle & emdlab_mlib_permanentMagnet
    
    methods
        
        function obj = emdlab_mlib_pm_Y22H()
        end
        
    end
    
end