classdef emdlab_mlib_pm_Y25 < handle & emdlab_mlib_permanentMagnet
    
    methods
        
        function obj = emdlab_mlib_pm_Y25()
        end
        
    end
    
end