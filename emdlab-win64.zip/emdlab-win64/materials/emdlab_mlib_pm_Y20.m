classdef emdlab_mlib_pm_Y20 < handle & emdlab_mlib_permanentMagnet
    
    methods
        
        function obj = emdlab_mlib_pm_Y20()
        end
        
    end
    
end