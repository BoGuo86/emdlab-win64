classdef emdlab_mlib_pm_Arnold_Magnetics_N38UH_120C < handle & emdlab_mlib_permanentMagnet
    
    methods
        
        function obj = emdlab_mlib_pm_Arnold_Magnetics_N38UH_120C()
        end
        
    end
    
end