classdef emdlab_mlib_pm_Y23 < handle & emdlab_mlib_permanentMagnet
    
    methods
        
        function obj = emdlab_mlib_pm_Y23()
        end
        
    end
    
end