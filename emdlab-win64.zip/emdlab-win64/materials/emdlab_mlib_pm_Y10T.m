classdef emdlab_mlib_pm_Y10T < handle & emdlab_mlib_permanentMagnet
    
    methods
        
        function obj = emdlab_mlib_pm_Y10T()
        end
        
    end
    
end