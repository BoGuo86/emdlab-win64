

p = [0,0;1,0;1,1;0,1];
t = [1,2,3;1,3,4];

mz = TMZPC(t,p)


m = TMDBC;
m.addmz(mz)