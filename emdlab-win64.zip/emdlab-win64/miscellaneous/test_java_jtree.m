

f = figure('menu', 'none');

[jt, wt] = javacomponent(javax.swing.JTree, [], f);

wt.Units = 'norm';
wt.Position = [0,0,1,1];
