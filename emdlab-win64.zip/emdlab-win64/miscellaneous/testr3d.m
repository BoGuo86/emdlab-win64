

function testr3d()

f = figure;
a = axes(f);

plot(a,[0,1],[0,1]);

r = rotate3d;
r.Enable('off');

end
