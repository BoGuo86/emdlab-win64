clc
clear

t = 0:1e-5:0.1;
Nt = length(t);

