
f = figure('menu', 'none');

b = javax.swing.JButton();

javacomponent(b, [], f)