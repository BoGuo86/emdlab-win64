

clc
clear

Ncoil = 190;

A = pi*0.7^2/4;

r = Ncoil*7*2*42e-3/37e6/A/1e-6