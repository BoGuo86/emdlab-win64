

t = linspace(0,2*pi,20);
t = t(1:end-1)';

x = cos(t);
y = sin(t);

m = mc_circularShell([x,y])
