f1 = trimesh(t1,p1(:,1),p1(:,2));hold on;axis off square
f2 = trimesh(t2,p2(:,1),p2(:,2));

view(2)
axis equal
axis off