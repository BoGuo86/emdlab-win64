try
  mySum(1,5)
catch ex
  error(ex.message)
end
