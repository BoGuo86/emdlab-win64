function direcFind2()

% loss at 50Hz
p50 = [0.03
    0.07
    0.15
    0.25
    0.37
    0.49
    0.63
    0.79
    0.96
    1.14
    1.35
    1.58
    1.83
    2.25
    2.62
    2.95
    3.21
    3.46];

% loss at 100Hz
p100 = [0.04
    0.17
    0.36
    0.60
    0.88
    1.21
    1.57
    1.98
    2.43
    2.93
    3.49
    4.12
    4.86
    5.78
    6.83];

% loss at 200Hz
p200 = [0.10
    0.44
    0.93
    1.55
    2.31
    3.21
    4.24
    5.41
    6.75
    8.25
    9.94
    11.8
    14.0
    16.6
    19.5];

% loss at 400Hz
p400 = [0.30
    1.18
    2.51
    4.25
    6.40
    9.01
    12.1
    15.7
    20.0
    24.9
    30.6
    37.1
    44.5
    53.0
    62.5];

% loss at 1000Hz
p1000 = [1.41
    5.10
    10.4
    17.7
    26.5
    37.9
    52.1
    69.5
    90.8
    116
    147];

% loss at 2500Hz
p2500 = [5.79
    20.3
    42.6
    74.1
    117
    174
    249
    346
    470
    629];

subplot(321)
b50 = 0.1:0.1:0.1*length(p50);
plot(b50,p50,'*');title('f = 50 Hz');xlabel('B [T]');ylabel('Loss [W/kg]')
subplot(322)
b100 = 0.1:0.1:0.1*length(p100);
plot(b100,p100,'*');title('f = 100 Hz');xlabel('B [T]');ylabel('Loss [W/kg]')
subplot(323)
b200 = 0.1:0.1:0.1*length(p200);
plot(b200,p200,'*');title('f = 200 Hz');xlabel('B [T]');ylabel('Loss [W/kg]')
subplot(324)
b400 = 0.1:0.1:0.1*length(p400);
plot(b400,p400,'*');title('f = 400 Hz');xlabel('B [T]');ylabel('Loss [W/kg]')
subplot(325)
b1000 = 0.1:0.1:0.1*length(p1000);
plot(b1000,p1000,'*');title('f = 1000 Hz');xlabel('B [T]');ylabel('Loss [W/kg]')
subplot(326)
b2500 = 0.1:0.1:0.1*length(p2500);
plot(b2500,p2500,'*');title('f = 2500 Hz');xlabel('B [T]');ylabel('Loss [W/kg]')

f = [50*ones(length(b50),1)
    100*ones(length(b100),1)
    200*ones(length(b200),1)
    400*ones(length(b400),1)
    1000*ones(length(b1000),1)
    2500*ones(length(b2500),1)];

b = [b50'
    b100'
    b200'
    b400'
    b1000'
    b2500'];

p = [p50;p100;p200;p400;p1000;p2500];

a11 = sum(f.^2 .* b.^4);
a12 = sum(f.^3 .* b.^4);
a13 = sum(f.^2.5 .* b.^3.5);
a21 = sum(f.^3 .* b.^4);
a22 = sum(f.^4 .* b.^4);
a23 = sum(f.^3.5 .* b.^3.5);
a31 = sum(f.^2.5 .* b.^3.5);
a32 = sum(f.^3.5 .* b.^3.5);
a33 = sum(f.^3 .* b.^3);

b1 =  sum(p .* f .* b.^2);
b2 =  sum(p .* f.^2 .* b.^2);
b3 =  sum(p .* f.^1.5 .* b.^1.5);
k = [a11,a12,a13;a21,a22,a23;a31,a32,a33]\[b1;b2;b3];

hold on
b = 0:0.1:1.8;
subplot(321);hold on
f = 50;
plot(b,k(1)*f*b.^2+k(2)*f^2*b.^2+k(3)*f^1.5 * b.^1.5)
subplot(322);hold on
f = 100;
plot(b,k(1)*f*b.^2+k(2)*f^2*b.^2+k(3)*f^1.5 * b.^1.5)
subplot(323);hold on
f = 200;
plot(b,k(1)*f*b.^2+k(2)*f^2*b.^2+k(3)*f^1.5 * b.^1.5)
subplot(324);hold on
f = 400;
plot(b,k(1)*f*b.^2+k(2)*f^2*b.^2+k(3)*f^1.5 * b.^1.5)
subplot(325);hold on
f = 1000;
plot(b,k(1)*f*b.^2+k(2)*f^2*b.^2+k(3)*f^1.5 * b.^1.5)
subplot(326);hold on
f = 2500;
plot(b,k(1)*f*b.^2+k(2)*f^2*b.^2+k(3)*f^1.5 * b.^1.5)

clc
disp(k)

end