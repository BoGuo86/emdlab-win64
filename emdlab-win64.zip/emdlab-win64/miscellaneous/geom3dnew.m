
clc
clear

m = TTMDBC;

