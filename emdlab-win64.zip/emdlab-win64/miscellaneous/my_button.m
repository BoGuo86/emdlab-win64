

[a,b] = javacomponent(javax.swing.JButton, [50,50,100,50],gcf)