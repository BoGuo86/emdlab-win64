
clc
clear

mz = QMZPC([1;2;3;4],[0,1,1,0;0,0,1,1])
