
clc
clear

m = TMDBC;
m.read_msh_bin('C:\Users\AliJamalifard\Desktop\gmesh\untitled.geo.msh');

m.showmzs