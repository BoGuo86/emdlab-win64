function lic = actxlicense(progid)

if strcmpi(progid, 'C1Chart2D8U.Control.1')
lic = 'mshrD';
return;
end
