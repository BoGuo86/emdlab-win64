

% 1 Definition of variables
%	1.1 Input Data	
Length = 352;
HeadReservoir = 15.347;
HeadValve = 0.0938;	
Diameter = 340;	
WaveSpeed = 0.714;			
UInitial = 1.14e-6;	
Nu = 9.8;	
Gravity = 0;		
Rho	= 0;		
Nx = 0;	
Nr = 0;			
NNx = 0;
OutNode1 = 0;
OutNode2 = 0;	
TClose = 0;	
TMax = 0;
First = 0;
Steady = 0;
EpsI = 0;
EpsV = 0;
