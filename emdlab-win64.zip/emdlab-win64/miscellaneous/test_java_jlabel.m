
f = figure('menu', 'none');

l = javax.swing.JLabel('salam');
l.setBackground(java.awt.Color.red)
l.setHorizontalAlignment(javax.swing.JLabel.CENTER)
javacomponent(l, [], f)