
m = TMDBC();
m = m.addmz('stator',s.m.mzs.stator);
m = m.addmz('c11',s.m.mzs.c11);
m = m.addmz('c21',s.m.mzs.c21);

% m = m.addmz('stator',s.m.mzs.stator);
% m = m.addmz('stator',s.m.mzs.stator);
% m = m.addmz('stator',s.m.mzs.stator);
% m = m.addmz('stator',s.m.mzs.stator);
