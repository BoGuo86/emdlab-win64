
m = TMZPC(s.m.mzs.stator.t,s.m.mzs.stator.p);
m.showm('w')

