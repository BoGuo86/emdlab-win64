clc
clear

g = G2DKERNEL;

