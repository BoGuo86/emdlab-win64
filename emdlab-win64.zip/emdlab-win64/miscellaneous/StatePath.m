
A = [-2,0;2,-3];
X0 = [2;-1];

dt = 1e-3;
t = 0:dt:1;
Nt = length(t);