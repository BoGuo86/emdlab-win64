
nodes = [-1,0;1,0;0,1;0,-1];

patch('faces',[1,2,3,4,3],'vertices',nodes, 'facecolor','b');