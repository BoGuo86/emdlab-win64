
function pe_rd

clc
clear

