clc
clear

m = TMDBC;

m.addmz('a',TMZPC([1,2,3;1,3,4],[1,1;3,2;3,3;2,3]));


m.showmzs